 #include <stdio.h>
    #define BEGIN {
    #define END }
    int main()
    BEGIN
        printf("Hello World!\n");

        return 0;
    END